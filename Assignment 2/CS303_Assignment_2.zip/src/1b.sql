SELECT grade, COUNT(ID)
FROM marks
GROUP BY grade;