UPDATE employee
SET city = "Newtown"
WHERE `employee name` = "Jones";