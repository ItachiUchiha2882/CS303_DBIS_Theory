DELETE FROM works
WHERE `company name` = "Small Bank Corporation";